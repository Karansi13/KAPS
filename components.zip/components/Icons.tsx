import {
  Moon,
  Sun,
  Ban,
  MoreVertical,
  Send,
  Menu,
  X,
  UserPlus2,
  Mic,
  Paperclip  
} from "lucide-react";

export const Icons = {
  Sun,
  Moon,
  Ban,
  Send,
  MoreVertical,
  Menu,
  X,
  UserPlus2,
  Mic,
  Paperclip  
};

export default Icons;
